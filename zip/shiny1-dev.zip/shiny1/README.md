# README

Run statistical analyses and generate reports using shiny.